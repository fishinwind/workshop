***************************
Log of experimental results
***************************

Problem Set 1
==============
:date: Wed Feb 12 12:56:45 MST 2014

- dumped states data out with run.sh script
- examined results.tab:

    1. sorting by population size worked fine
    2. sorting by murder rate seems broken, need to debug

TODO:

    1. debug sorting by murder rate, rerun analysis

Problem Set 2
==============
:date:  Wed Feb 12 13:18:56 MST 2014

- Yikes! that was hard.
- examined results.tab:

    1. Checked everything offline and seems to be correct.
    2. Will run through examples in class.

TODO:

    1. Perhaps make these problem sets a bit easier? Or skip the focus on
       ``awk``.

