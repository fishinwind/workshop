mkdir -p "$HOME/workshop-problem-sets/problem-set-1"
cd workshop-problem-sets/problem-set-1/
mkdir results data doc

