#! /usr/bin/env bash

projects=$HOME/workshop-projects
results=$projects/results
data=$projects/data

today=$(date +%Y-%m-%d)


